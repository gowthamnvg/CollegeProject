<html>
<head lang="en">
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="bootstrap-3.2.0-dist\css\bootstrap.css"> <!--css file link in bootstrap folder-->
    <title>View User1</title>
</head>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>

<body>

<div class="table-scrol">
  
  <div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
        <thead>

        <tr>

         <td bgcolor="#00FFFF">id</td>
            <td bgcolor="#00FFFF">firstname</td>
           <td bgcolor="#FF0000">User pass</td>
            <td bgcolor="#00FFFF">User email</td>
            

        </tr>
        </thead>

        <?php

        include("database/db_conection.php");
     

        $view_users_query="select * from users";//select query for viewing users.
        $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.
       
        while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
        {
            
            
            $id=$row[0];
            $firstname=$row[1];
            $password=$row[3];
            $email=$row[4];


        }
        ?>

        <tr>
<!--here showing results in the table -->
            <td bgcolor="#000080"><?php echo $id;    ?></td>
            <td bgcolor="#000080"><?php echo $firstname;  ?></td>
             <td bgcolor="#000080"><?php echo $password;  ?></td>
             <td bgcolor="#000080"><?php echo $email;  ?></td>
          
        
        
            
        </tr>


    </table>
        </div>
</div>


</body>

</html>
