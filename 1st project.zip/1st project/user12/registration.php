
<html>
<head lang="en">
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="bootstrap-3.2.0-dist\css\bootstrap.css">
    <title>Registration</title>
</head>
<style>
    .login-panel {
        margin-top: 150px;

</style>
<body>

<div class="container"><!-- container class is used to centered  the body of the browser with some decent width-->
    <div class="row"><!-- row class is used for grid system in Bootstrap-->
        <div class="col-md-4 col-md-offset-4"><!--col-md-4 is used to create the no of colums in the grid also use for medimum and large devices-->
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Registration</h3>
                </div>
                <div class="panel-body">
                    <form role="form" method="post" action="registration.php">
                        <fieldset>
                            <div class="form-group">
                                <input class="form-control" placeholder="firstname" name="firstname" type="text" autofocus>
                            </div>

                            <div class="form-group">
                                <input class="form-control" placeholder="lastname" name="lastname" type="text" autofocus>
                            </div>

                            <div class="form-group">
                                <input class="form-control" placeholder="Password" name="password" type="password" value="">
                            </div>

                            <div class="form-group">
                                <input class="form-control" placeholder="email" name="email" type="email" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="gender" name="gender" type="text" autofocus>
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="address" name="address" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="dob" name="dob" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="city" name="city" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="sslcmark" name="sslcmark" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="hscmark" name="hscmark" type="text" autofocus>
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="nameoftheschool" name="nameoftheschool" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="mothertongue" name="mothertongue" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="fathername" name="fathername" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="mothername" name="mothername" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="state" name="state" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="religion" name="religion" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="nationality" name="nationality" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="fatheroccupation" name="fatheroccupation" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="motheroccupation" name="motheroccupation" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="annualincome" name="annualincome" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="parentmobilenumber" name="parentmobilenumber" type="text" autofocus>
                            </div>
                             <div class="form-group">
                                <input class="form-control" placeholder="studentmobilenumber" name="student" type="text" autofocus>
                            </div>
                             <input class="btn btn-lg btn-success btn-block" type="submit" value="register" name="register" >

                        </fieldset>
                    </form>
                    <center><b>Already registered ?</b> <br></b><a href="welcome.php">Login here</a></center><!--for centered text-->
                </div>
            </div>
        </div>
    </div>
</div>

</body>

</html>

<?php

include("database/db_conection.php");//make connection here
if(isset($_POST['register']))
{
    $firstname=$_POST['firstname'];//here getting result from the post array after submitting the form.
    $lastname=$_POST['lastname'];//same
    $password=$_POST['password'];//same
    $email=$_POST['email'];
    $gender=$_POST['gender'];
    $address=$_POST['address'];
    $dob=$_POST['dob'];
    $city=$_POST['city'];
    $sslcmark=$_POST['sslcmark'];
    $hscmark=$_POST['hscmark'];
    $nameoftheschool=$_POST['nameoftheschool'];
    $mothertongue=$_POST['mothertongue'];
    $fathername=$_POST['fathername'];
    $mothername=$_POST['mothername'];
    $state=$_POST['state'];
    $religion=$_POST['religion'];
    $nationality=$_POST['nationality'];
    $fatheroccupation=$_POST['fatheroccupation'];
    $motheroccupation=$_POST['motheroccupation'];
    $annualincome=$_POST['annualincome'];
    $parentmobilenumber=$_POST['parentmobilenumber'];
    $studentmobilenumber=$_POST['studentmobilenumber'];

    if($firstname=='')
    {
        //javascript use for input checking
        echo"<script>alert('Please enter the firstname')</script>";
exit();//this use if first is not work then other will not show
    }

    if($password=='')
    {
        echo"<script>alert('Please enter the password')</script>";
    }
    if($email=='')
    {
        echo"<script>alert('Please enter the email')</script>";
    exit();
    }
    
//here query check weather if user already registered so can't register again.
    $check_email_query="select * from users WHERE user_email='$user_email'";
    $run_query=mysqli_query($dbcon,$check_email_query);

    if(mysqli_num_rows($run_query)>0)
    {
echo "<script>alert('Email $email is already exist in our database, Please try another one!')</script>";
exit();
    }
//insert the user into the database.
    $insert_user="insert into users (firstname,lastname,password,email,gender,address,dob,city,sslcmark,hscmark,mothertongue,fathername,mothername,state,religion,nationality,fatheroccupation,motheroccupation,annualincome,parentmobilenumber,studentmobilenumber) VALUE ('$firstname','$lastname','$password','$email','$gender','$address','$dob','$city','$sslcmark','$hscmark','$mothertongue','$fathername','$mothername','$state','$religion','$nationality','$fatheroccupation','$motheroccupation','$annualincome','$parentmobilenumber','$studentmobilenumber')";
    if(mysqli_query($dbcon,$insert_user))
    {
        echo"<script>window.open('welcome.php','_self')</script>";
    }

}

?>